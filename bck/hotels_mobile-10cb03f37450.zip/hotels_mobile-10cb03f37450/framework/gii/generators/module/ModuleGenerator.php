<?php

class ModuleGenerator extends CCodeGenerator
{
	public $codeModel='gii.generators.module.ModuleCode';
}